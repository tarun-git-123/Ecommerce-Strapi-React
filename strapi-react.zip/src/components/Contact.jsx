import React from 'react'

const Contact = () => {
  return (
    <div>This is contact us page</div>
  )
}

export default Contact