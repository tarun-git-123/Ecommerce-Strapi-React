import React from 'react'

const Blog = () => {
  return (
    <div>This is blog page</div>
  )
}

export default Blog